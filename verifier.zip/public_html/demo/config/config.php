<?php
              define('DB_HOST','localhost');
              define('DB_USER','eduw_demo');
              define('DB_PASS','Murugan@321');
              define('DB_NAME','eduw_demo');
              ?>