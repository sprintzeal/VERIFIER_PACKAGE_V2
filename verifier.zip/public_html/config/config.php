<?php
              define('DB_HOST','');
              define('DB_USER','');
              define('DB_PASS','');
              define('DB_NAME','');
              ?>